cp -r ../prod/BlindJump.app/ ~/Applications/xs
