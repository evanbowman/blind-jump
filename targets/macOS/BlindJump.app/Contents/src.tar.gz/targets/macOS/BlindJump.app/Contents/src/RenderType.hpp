//========================================================================//
// Copyright (C) 2016 Evan Bowman                                         //
// Liscensed under GPL 3, see: <http://www.gnu.org/licenses/>.            //
//========================================================================//

#pragma once

enum class Rendertype {
	shadeDefault,
	shadeWhite,
	shadeGldnGt,
	shadeRuby,
	shadeElectric,
	shadeNone
};
